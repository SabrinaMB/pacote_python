# __init__.py
from .dev_aberto import hello
